function y=f1(x)
  y = asin(x)+acos(exp(1-x));
