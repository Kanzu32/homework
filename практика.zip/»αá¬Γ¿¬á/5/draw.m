function draw(x, y)
  if (length(x) == length(y))
    plot(x, y);
  endif
